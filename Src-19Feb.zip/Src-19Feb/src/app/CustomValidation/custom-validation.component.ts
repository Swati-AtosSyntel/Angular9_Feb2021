import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
 import {gte} from './gte.validator';
@Component({
  selector: 'app-custom-validation',
  templateUrl: './custom-validation.component.html',
  
})
export class CustomValidationComponent implements OnInit {

  constructor() { }
myForm;

  ngOnInit(): void {

    this.myForm=new FormGroup({
      numVal:new FormControl("",[gte])
      
    });
  }
  get numVal(){
    return this.myForm.get('numVal');
  }


OnSubmit()
{
  alert(this.myForm.value);
}
}
