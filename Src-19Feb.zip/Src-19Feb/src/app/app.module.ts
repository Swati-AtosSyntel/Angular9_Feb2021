

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { App1Component } from './app1/app1.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { GenderPipe } from './gender.pipe';
 import {HttpClientModule} from '@angular/common/http';
import { HttpClientApp1Component } from './http-client-app1/http-client-app1.component';
import { IODecoratorComponent } from './iodecorator/iodecorator.component';
import { ChildComponent } from './iodecorator/child/child.component';
import { TemplateFormsComponent } from './template-forms/template-forms.component';
import { ReactiveForms1Component } from './reactive-forms1/reactive-forms1.component';

import {CustomValidationComponent} from './CustomValidation/custom-validation.component';
import { Reactiveforms2Component } from './reactiveforms2/reactiveforms2.component';
import {Routes,RouterModule} from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';


const routes:Routes=[
  {path:'templateforms',component:TemplateFormsComponent},
  {path:'reactiveforms1',component:ReactiveForms1Component},
  {path:'apiGitHub',component:HttpClientApp1Component},
  {path:'',redirectTo:'/templateforms',pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent}
  
]

@NgModule({
  declarations: [
    AppComponent,
    App1Component,
    AngularPipesComponent,
    GenderPipe,
    HttpClientApp1Component,
    IODecoratorComponent,
    ChildComponent,
    TemplateFormsComponent,
    ReactiveForms1Component,
    CustomValidationComponent,
    Reactiveforms2Component,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
