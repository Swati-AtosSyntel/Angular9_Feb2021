import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iodecorator',
  templateUrl: './iodecorator.component.html',
  styleUrls: ['./iodecorator.component.css']
})
export class IODecoratorComponent implements OnInit {
thankYouText="";
  constructor() { }

  ngOnInit(): void {
  }

  num=0;
  SendToChild(){
    this.num++;
  }

  receiveThanks(event){
    this.thankYouText=event;
    console.log(this.thankYouText);
  }
}
