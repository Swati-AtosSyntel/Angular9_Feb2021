import { Component, Input, OnInit, Output } from '@angular/core';
import * as EventEmitter from 'events';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
@Input()
  numReceived;
  @Output() thanks: EventEmitter
  
  sayThanks($event) { 
      this.thanks.emit('Thank you'); 
    }



  constructor() { 
    this.thanks=new EventEmitter();
  }

  ngOnInit(): void {
  }



}
