export class Repository
{
    id:string;
    name:string;
    html_url:string;
    description:string;
}