import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //template:`<h1>
  //{{title}}
  //</h1>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularApp';
  show=true;
  colors=["Green","Red","Blue","Yellow"];
  isSelected:boolean;

  constructor(){
    this.isSelected=false;
  }

  changeTitle():void{
    this.title="This is my first Angular Application.";
  }

}
