import { Component, Input, OnInit, Output } from '@angular/core';
import * as EventEmitter from 'events';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
@Input()
  numReceived;
 //thanks:string;
 /* @Output()
thanks=new EventEmitter(); */



  constructor() { }

  ngOnInit(): void {
  }

 /*  sayThanks($event){
   this.thanks.emit("Thank You");
  } */

}
