import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IODecoratorComponent } from './iodecorator.component';

describe('IODecoratorComponent', () => {
  let component: IODecoratorComponent;
  let fixture: ComponentFixture<IODecoratorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IODecoratorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IODecoratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
