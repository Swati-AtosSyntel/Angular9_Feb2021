import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-forms1',
  templateUrl: './reactive-forms1.component.html',
  styleUrls: ['./reactive-forms1.component.css']
})
export class ReactiveForms1Component implements OnInit {

  constructor() { }
formdata;
emailID;
  ngOnInit(): void {

    this.formdata=new FormGroup({
      emailID:new FormControl("",Validators.required),
      Password:new FormControl("")
    });
  }

OnClickSubmit(data)
{
  this.emailID=data.emailID;
}
}
