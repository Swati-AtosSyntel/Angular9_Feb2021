import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientApp1Component } from './http-client-app1.component';

describe('HttpClientApp1Component', () => {
  let component: HttpClientApp1Component;
  let fixture: ComponentFixture<HttpClientApp1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HttpClientApp1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HttpClientApp1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
