import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Repository } from '../repository';

@Component({
  selector: 'app-http-client-app1',
  templateUrl: './http-client-app1.component.html',
  styleUrls: ['./http-client-app1.component.css']
})
export class HttpClientApp1Component implements OnInit {
  
username:string="swati";
  baseUrl:string="https://api.github.com/";
  repos:Repository[];

  constructor(public http:HttpClient) { }

  ngOnInit(): void {
    this.GetRepository();
  }

  public GetRepository(){
    return this.http.get<Repository[]>(this.baseUrl+'users/'+this.username+'/repos')
    .subscribe(
      (response)=>{
        console.log('Response Received');
        console.log(response);
        this.repos=response;
  
      },
      (error)=>{
        console.log("Request failed");
        alert(error);
      },
      ()=>{
        console.log("Request Completed Successfully");
      }

    )

  }

}
